@extends('errors.layout')

@section('code', '410')
@section('title', 'Gone')
@section('category', 'Client Error')
@section('accent_color', '#94a3b8')
@section('description', 'The requested page has been permanently deleted and will not return.')

@section('icon')
<svg class="w-8 h-8 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
</svg>
@endsection
