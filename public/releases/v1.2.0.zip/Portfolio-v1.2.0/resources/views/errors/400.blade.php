@extends('errors.layout')

@section('code', '400')
@section('title', 'Bad Request')
@section('category', 'Client Error')
@section('accent_color', '#f59e0b')
@section('description', 'The server cannot process the request due to malformed syntax.')

@section('icon')
<svg class="w-8 h-8 text-amber-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
</svg>
@endsection
