<?php

namespace App\Models;

use App\Traits\AutoSortOrderById;
use App\Traits\HasCategoryOptions;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Project extends Model
{
    use HasFactory, HasCategoryOptions, AutoSortOrderById;

    protected $fillable = [
        'title',
        'category',
        'subtitle',
        'description',
        'image_url',
        'demo_url',
        'github_url',
        'tags',
        'theme',
        'is_featured',
        'sort_order',
    ];

    protected function casts(): array
    {
        return [
            'is_featured' => 'boolean',
        ];
    }

    public function getImageUrlAttribute($value = null): ?string
    {
        if (empty($value)) {
            return null;
        }

        if (str_starts_with($value, 'http://') || str_starts_with($value, 'https://') || str_starts_with($value, '//')) {
            return $value;
        }

        return asset($value);
    }
}
