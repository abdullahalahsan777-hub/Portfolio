<?php

namespace App\Models;

use App\Traits\AutoSortOrderById;
use App\Traits\HasCategoryOptions;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Service extends Model
{
    use HasFactory, HasCategoryOptions, AutoSortOrderById;
    
    protected $fillable = [
        'title',
        'description',
        'icon',
        'category',
        'theme',
        'sort_order',
    ];
}
